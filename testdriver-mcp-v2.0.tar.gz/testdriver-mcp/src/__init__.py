"""TestDriver MCP Framework - Autonomous AI-Powered Testing Platform."""

__version__ = "2.0.0"
__author__ = "Manus AI"
